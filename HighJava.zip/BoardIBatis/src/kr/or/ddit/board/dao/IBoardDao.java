package kr.or.ddit.board.dao;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardDao {

	public int insertBoard(BoardVO bv);

	public List<BoardVO> DisplayBoardAll();

	public int updateBoard(BoardVO bv);

	public boolean getBoard(String boardNo);

	public int DeleteBoard(String boardNo);

	public List<BoardVO> SearchBoard(BoardVO bv);
	
}
