package kr.or.ddit.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Application Lifecycle Listener implementation class SessionAttributeListener
 *
 */
@WebListener
public class SessionAttributeListener implements HttpSessionAttributeListener {

    /**
     * Default constructor. 
     */
    public SessionAttributeListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionAttributeListener#attributeAdded(HttpSessionBindingEvent)
     */
    public void attributeAdded(HttpSessionBindingEvent hsbe)  { 
    	 System.out.println("SessionAttributeListener : attributeAdded() 호출됨."+hsbe.getName() + " => " + hsbe.getValue());
    }

	/**
     * @see HttpSessionAttributeListener#attributeRemoved(HttpSessionBindingEvent)
     */
    public void attributeRemoved(HttpSessionBindingEvent hsbe)  { 
    	System.out.println("SessionAttributeListener : attributeRemoved() 호출됨."+hsbe.getName() + " => " + hsbe.getValue());
    }

	/**
     * @see HttpSessionAttributeListener#attributeReplaced(HttpSessionBindingEvent)
     */
    public void attributeReplaced(HttpSessionBindingEvent hsbe)  { 
         System.out.println("SessionAttributeListener : attributeReplaced() 호출됨."+hsbe.getName() + " => " + hsbe.getValue());
    }
	
}
