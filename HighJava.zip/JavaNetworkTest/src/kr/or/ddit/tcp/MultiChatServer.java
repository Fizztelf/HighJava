package kr.or.ddit.tcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class MultiChatServer {

	// 대화명, 클라이언트의 Socket을 저장하기 위한 Map변수 선언
	private Map<String, Socket> clients;

	public MultiChatServer() {
		// 동기화 처리가 가능하도록 Map객체 생성
		clients = Collections.synchronizedMap(new HashMap<>());
	}

	// 서버 시작
	public void serverStart() {

		ServerSocket serverSocket = null;
		Socket socket;

		try {
			serverSocket = new ServerSocket(7777);
			System.out.println("서버가 시작되었습니다");

			while (true) {
				// 클라이언트의 접속을 대기한다.
				socket = serverSocket.accept();

				System.out.println("[" + socket.getInetAddress() + " : " + socket.getPort() + "]에서 접속하였습니다");
				
				// 메시지 전송 처리를 하는 쓰레드 생성 및 실행
				ServerReceiver reciver = new ServerReceiver(socket);
				reciver.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 서버 소켓 닫기
			if(serverSocket != null) {
				try {serverSocket.close();} catch (IOException e) {}
			}
		}
	}

	/**
	 * 대화방 즉, Map에 저장된 전체 유저에게 안내 메시지를 전송하는 메서드
	 * @param msg
	 */
	public void sendMessage(String msg) {
		// Map에 저장된 유저의 대화명 리스트를 추출(key값 구하기)
		Iterator<String> it = clients.keySet().iterator();
		while(it.hasNext()) {
			try {
				String name = it.next(); // 대화명(key) 구하기
				
				// 대화명에 해당하는 Socket의 OutputStream객체 구하기
				DataOutputStream out = new DataOutputStream(clients.get(name).getOutputStream());
				out.writeUTF(msg);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 대화방 즉, Map에 저장된 전체 유저에게 대화 메시지를 전송하는 메서드
	 * @param msg 보낼 메시지
	 * @param from 보낸 사람 대화명
	 */
	public void sendMessage(String msg, String from) {
		// Map에 저장된 유저의 대화명 리스트를 추출(key값 구하기)
		Iterator<String> it = clients.keySet().iterator();
		while(it.hasNext()) {
			try {
				String name = it.next(); // 대화명(key) 구하기
				// 대화명에 해당하는 Socket의 OutputStream객체 구하기
				DataOutputStream out = new DataOutputStream(clients.get(name).getOutputStream());
				out.writeUTF("[" + from + "]" + msg);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 특정 사용자에게 귓속말 보내기
	 * @param ws 보낼 귓말
	 * @param to 받는 사람 대화명
	 * @param from 보낸 사람 대화명
	 */
	public void Whisper(String ws, String to, String from) {
		boolean chk = false;	
		Iterator<String> it = clients.keySet().iterator();
		while(it.hasNext()) {
			String name = it.next();
			if(to.equals(name)) {	// 이름이 있는지 없는지 체크
				chk = true;
				break;
			}
		}
		
		if(chk) {
			try {
				DataOutputStream fdos = new DataOutputStream(clients.get(from).getOutputStream());
				DataOutputStream tdos = new DataOutputStream(clients.get(to).getOutputStream());
				
				fdos.writeUTF(to + "에게 보낸 귓말" + " : " +ws);
				tdos.writeUTF(from + "님에게 온 귓말" + " : " + ws);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				DataOutputStream dos = new DataOutputStream(clients.get(from).getOutputStream());
				dos.writeUTF(to + "사용자가 존재하지 않습니다.");
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	// 서버에서 클라이언트로 메시지를 전송할 Thread를 Inner클래스로 정의
	// Inner 클래스에는 부모클래스의 멤버들을 직접 사용할 수 있다.
	class ServerReceiver extends Thread {

		private Socket socket;
		private DataInputStream dis;
		private String name;

		public ServerReceiver(Socket socket) {
			this.socket = socket;

			try {
				// 수신용
				dis = new DataInputStream(socket.getInputStream());
			} catch (IOException e) {
				e.printStackTrace();
			} 
		}

		@Override
		public void run() {
			try {
				// 서버에서 클라이언트가 보내는 최초의 메시지 즉, 대화명을 수신한다
				name = dis.readUTF();
				
				// 대화명을 받아서 다른 모든 클라이언트에게 대화방 참여 메시지를 보낸다.
				sendMessage("#" + name + " 님이 입장하셨습니다");
						
				// 대화명과 소켓정보를 Map에 저장한다
				clients.put(name, socket);
				System.out.println("현재 서버 접속자 수는 : " + clients.size() + "명 입니다");
				
				// 이 후의 메시지 자리는 반복문으로 처리한다.
				// 한 클라이언트가 보낸 메시지를 다른 모든 클라이언트에게 보내준다.
				while(dis != null) {
					String msg = dis.readUTF();
//					/w 대화명   ==> 공백에서 split
					String[] list = msg.split(" ");	
					if(list.length > 2) {
//				    	"/w 대화명 내용" => [0]번방에는 /w , [1]번방 대화명 , [2]번방에는 내용
//						그렇기 때문에 list.length의 길이는 3
						String to = list[1];	// 대화명을 to에 저장
						String spl = "";	// 
						for(int i=2; i<list.length; i++) {	
							spl += list[i] + " ";	// 내용을 spl에 계속 +=
						}
						if(list[0].equals("/w")) {
							Whisper(spl, to, name);
						}
					} else {
						sendMessage(msg, name);
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 이 finally 영역이 실행된다는 것은 클라이언트의 접속이 종료되었다는 뜻이다.
			
				sendMessage(name + "님이 나가셨습니다.");
				
				// Map에서 해당 대화명을 삭제한다.
				clients.remove(name);
				
				System.out.println("[" + socket.getInetAddress() + " : " + socket.getPort() + "]에서 접속을 종료했습니다.");
				System.out.println("현재 서버 접속자 수는 : " + clients.size() + "명 입니다");
			}
		}
	}
	public static void main(String[] args) {
		new MultiChatServer().serverStart();
	}
}
