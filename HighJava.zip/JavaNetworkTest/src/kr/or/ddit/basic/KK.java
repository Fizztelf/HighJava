package kr.or.ddit.basic;

public class KK {
	public static void main(String[] args) {

		String msg = "대덕인 재개 발원";
		String[] list = msg.split(" ");
		
		System.out.println(list.length);
		
		String to = list[1];
		String spl = "";
		
		for(int i=2; i<list.length; i++) {
			System.out.println(list[i]);
			spl += list[i] + " ";
		}
	}
}
