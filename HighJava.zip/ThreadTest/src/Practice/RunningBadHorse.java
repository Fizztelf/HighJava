package Practice;

public class RunningBadHorse {

}
