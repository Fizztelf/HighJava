package Practice;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *문제)

호텔 운영을 관리하는 프로그램 작성.(Map이용)
 - 키값은 방번호 
 
실행 예시)

**************************
호텔 문을 열었습니다.
**************************

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 101 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 홍길동 <-- 입력
체크인 되었습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 102 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 성춘향 <-- 입력
체크인 되었습니다

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 3 <-- 입력

방번호 : 102, 투숙객 : 성춘향
방번호 : 101, 투숙객 : 홍길동

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 2 <-- 입력

어느방을 체크아웃 하시겠습니까?
방번호 입력 => 101 <-- 입력
체크아웃 되었습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 102 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 허준 <-- 입력
102방에는 이미 사람이 있습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 2 <-- 입력

어느방을 체크아웃 하시겠습니까?
방번호 입력 => 101 <-- 입력
101방에는 체크인한 사람이 없습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 3 <-- 입력

방번호 : 102, 투숙객 : 성춘향

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 4 <-- 입력

**************************
호텔 문을 닫았습니다.
**************************

 *
 */
public class HotelManager {
	private Scanner sc;
	private Map<String, Hotel> hotelMap;
	
	public HotelManager() {
	sc = new Scanner(System.in);	
	hotelMap = new HashMap<>();
	
	}
	//메뉴 출력
	public void displayMenu() {
		System.out.println("*******************************");
		System.out.println("\t호텔 문을 열었습니다.\t");
		System.out.println("*******************************");
		System.out.println("************************************");
		System.out.println("어떤 업무를 하시겠습니까?");
		System.out.println("1.체크인    2.체크아웃     3.객실상태     4.업무종료");
		System.out.println("************************************");
		System.out.println();
	}
	
	// 프로그램 시작
	public void hotelOpen() {
		while (true) {
			displayMenu(); // 메뉴 출력
			int menuNum = sc.nextInt(); // 메뉴 번호 입력

			switch (menuNum) {
			case 1:
				checkIn(); // 체크인
				break;
			case 2:
				checkOut(); // 체크아웃
				break;
			case 3:
				roomState(); // 객실상태
				break;
			case 4:
				System.out.println("프로그램을 종료합니다...");
				return;
			default:
				System.out.println("잘못 입력했습니다. 다시입력하세요.");
			} // switch문
		} // while문
	}
	
	/**
	 * 고객 정보를 삭제하는 메서드
	 */
	private void checkOut() {
		System.out.println();
		System.out.println("어느 방을 체크아웃 하시겠습니까?");
		System.out.print("객실 번호 >> ");
		String rNum = sc.next();
		
		ObjectInputStream ois;
		
		try {
			ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream("d:/D_Other/hotel.bin")));
			Object obj = null;
			while((obj=ois.readObject()) != null) {
				hotelMap = (Map<String, Hotel>) obj;
				if(hotelMap.remove(rNum) == null) {
					System.out.println(rNum + " 번 방에 사용 중인 고객님은 없습니다.");
				} else {
					System.out.println("체크아웃하셨습니다. 저희 호텔을 이용해주셔서 감사합니다.");
					System.out.println("좋은 하루 되십시오. 고객님.");
				}
				ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("d:/D_Other/hotel.bin")));
				oos.writeObject(hotelMap);
				System.out.println("정보 저장 완료");
				oos.close();
			}
		} catch (ClassNotFoundException | IOException e) {}
	}
	
	
	
	/**
	 * 호텔에 머무는 고객들의 객실 상태를 알려주는 메서드
	 */
	private void roomState() {
		Set<String> keySet = hotelMap.keySet();
		System.out.println("=====================================");
		System.out.println(" 번호\t객실번호\t\t이름 ");
		System.out.println("=====================================");
		
		ObjectInputStream ois;
		
		try {
			ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream("d:/D_Other/hotel.bin")));
			Object obj = null;
			while((obj=ois.readObject()) != null) {
				hotelMap = (Map<String, Hotel>)obj;
			}
			
		} catch (ClassNotFoundException | IOException e) {}
		
		if(keySet.size() == 0) {
			System.out.println("등록된 룸이 없습니다");
		} else {
			Iterator<String> it = keySet.iterator();
			
			int count = 0;
			while(it.hasNext()) {
				count++;
				String rNum = it.next();
				Hotel h = hotelMap.get(rNum);
				System.out.println(" " + count + "번"+ "\t" +"방번호 : "+ h.getrNum() +"\t" + "투숙객 : "+ h.getName());

			}
		}
		System.out.println("================================");
	}
	
	/**
	 * 새로운 고객 정보를 등록하는 메서드
	 */
	private void checkIn() {
		while(true) {
			
			ObjectInputStream ois;
			try {
				FileInputStream fis = new FileInputStream("d:/D_Other/hotel.bin");
				ois = new ObjectInputStream(new BufferedInputStream(fis));
				Object obj = null;
				while((obj=ois.readObject()) != null) {
					hotelMap = (Map<String, Hotel>) obj;
				}
				
				
			} catch (ClassNotFoundException | IOException e) {
				
			}
			
			System.out.println();
			System.out.println("어느 방에 체크인 하시겠습니까?");
			System.out.print("방 번호 입력 => ");
			String rNum = sc.next();
			
			if(hotelMap.get(rNum) != null) {
				System.out.println("죄송합니다. 다른 손님이 방을 사용중입니다.");
				return;
			}
			
			sc.nextLine();
			System.out.println("성함이 어떻게 되십니까?");
			System.out.print("이름 입력 => ");
			String name = sc.next();
			
			hotelMap.put(rNum, new Hotel(rNum, name));
			System.out.println(name + " 님 체크인 준비가 완료되었습니다.");
			
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("d:/D_Other/hotel.bin")));
				oos.writeObject(hotelMap);
				System.out.println("정보 저장 완료");
				oos.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return;
		}
	}
	
	
	public static void main(String[] args) {
		new HotelManager().hotelOpen();
	}


}

/**
 * 고객의 정보를 저장하기 위한 VO클래스
 */
class Hotel implements Serializable{
	private String rNum;
	private String name;
	
	public Hotel(String rNum, String name) {
		super();
		this.name = name;
		this.rNum = rNum;
	}
	
	public String getrNum() {
		return rNum;
	}


	public void setrNum(String rNum) {
		this.rNum = rNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Hotel [rNum=" + rNum + ", name=" + name + "]";
	}
	
}
