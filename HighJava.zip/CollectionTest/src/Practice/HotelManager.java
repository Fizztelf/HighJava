package Practice;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *문제)

호텔 운영을 관리하는 프로그램 작성.(Map이용)
 - 키값은 방번호 
 
실행 예시)

**************************
호텔 문을 열었습니다.
**************************

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 101 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 홍길동 <-- 입력
체크인 되었습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 102 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 성춘향 <-- 입력
체크인 되었습니다

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 3 <-- 입력

방번호 : 102, 투숙객 : 성춘향
방번호 : 101, 투숙객 : 홍길동

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 2 <-- 입력

어느방을 체크아웃 하시겠습니까?
방번호 입력 => 101 <-- 입력
체크아웃 되었습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 1 <-- 입력

어느방에 체크인 하시겠습니까?
방번호 입력 => 102 <-- 입력

누구를 체크인 하시겠습니까?
이름 입력 => 허준 <-- 입력
102방에는 이미 사람이 있습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 2 <-- 입력

어느방을 체크아웃 하시겠습니까?
방번호 입력 => 101 <-- 입력
101방에는 체크인한 사람이 없습니다.

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 3 <-- 입력

방번호 : 102, 투숙객 : 성춘향

*******************************************
어떤 업무를 하시겠습니까?
1.체크인  2.체크아웃 3.객실상태 4.업무종료
*******************************************
메뉴선택 => 4 <-- 입력

**************************
호텔 문을 닫았습니다.
**************************

 *
 */
public class HotelManager {
   private Scanner sc;
   
   // Map은 Key값과 Value 값을 한 쌍으로 관리하는 객체
   //      Key값은 중복을 허용하지 않고 순서가 없다.(Set의 특징)
   //      Value값은 중복을 허용한다.(List의 특징)
   private Map<String, Hotel> hotelMap;
   
   public HotelManager() {
   sc = new Scanner(System.in);   
   hotelMap = new HashMap<>();
   
   }

   /**
    * 프로그램을 시작하는 메서드
    */
   public void hotelOpen() {
      
      input();
      
      while (true) {
         displayMenu(); // 메뉴 출력
         int menuNum = sc.nextInt(); // 메뉴 번호 입력

         switch (menuNum) {
         case 1:
            checkIn(); // 체크인
            break;
         case 2:
            checkOut(); // 체크아웃
            break;
         case 3:
            roomState(); // 객실상태
            break;
         case 4:
            hotelClose();
            return;
         default:
            System.out.println("잘못 입력했습니다. 다시입력하세요.");
         } // switch문
      } // while문
   }
   
   /**
    * 호텔 문을 닫는 메서드
    */
   private void hotelClose() {
      ouput(); // 자료 저장하기
      
      System.out.println("**************************");
      System.out.println("호텔 문을 닫았습니다.");
      System.out.println("**************************");
   }

   /**
    * 메뉴를 출력하는 메서드
    */
   public void displayMenu() {
      System.out.println("*******************************");
      System.out.println("\t호텔 문을 열었습니다.\t");
      System.out.println("*******************************");
      System.out.println("************************************");
      System.out.println("어떤 업무를 하시겠습니까?");
      System.out.println("1.체크인    2.체크아웃     3.객실상태     4.업무종료");
      System.out.println("************************************");
      System.out.print("메뉴선택 =>");
      System.out.println();
   }
   
   /**
    * 기존 자료를 읽어오는 메서드
    */
   private void input() {
      //입력용 스트림 객체 생성
      try {
         ObjectInputStream ois = 
               new ObjectInputStream(
                     new BufferedInputStream(	// 보조 스트림, 입출력 향상 역할
                           new FileInputStream("d:/D_Other/hotel.bin")));
         
         Object obj = null;	// 읽어올 자료를 객체에 담을 변수
         
         try {
            while((obj=ois.readObject()) != null) {
            	
               // 읽어온 데이터를 hotelMap으로 변환한 후에 대입
               hotelMap = (Map<String, Hotel>)obj; 	// 두 개의 type이 다르기 때문에 형변환
            }
            
            //객체 닫기
            ois.close();
            
         } catch(ClassNotFoundException e) {
            e.printStackTrace();
         }
      } catch (IOException e) {
      //   e.printStackTrace();  더 읽어올 객체가 없으면 예외가 발생하기 때문에 주석처리.
      }
   }
   
   
   /**
    * 자료를 저장하는 메서드
    */
   private void ouput() {
	   
      // 저장한 객체를 읽어와 출력하기
      // 입력용 스트림 객체 생성
      try {
         ObjectOutputStream oos = 
               new ObjectOutputStream(
                     new BufferedOutputStream(	// 보조 스트림, 입출력 향상 역할
                           new FileOutputStream("d:/D_Other/hotel.bin")));
         
         // hotelMap 출력
         oos.writeObject(hotelMap);
         
         // 객체 닫기
         oos.close();
      
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   
   
   /**
    * 고객 정보를 삭제하는 메서드
    */
   private void checkOut() {
      System.out.println();
      System.out.println("어느 방을 체크아웃 하시겠습니까?");
      System.out.print("객실 번호 >> ");
      String rNum = sc.next();
      
      if(hotelMap.remove(rNum) == null) {
         System.out.println(rNum + " 번 방에 사용 중인 고객님은 없습니다.");
      } else {
         System.out.println("체크아웃하셨습니다. 저희 호텔을 이용해주셔서 감사합니다.");
         System.out.println("좋은 하루 되십시오. 고객님.");
      }
   }
   
   
   
   /**
    * 호텔에 머무는 고객들의 객실 상태를 알려주는 메서드
    */
   private void roomState() {
      
	  // hotelMap에 저장된 데이터들을 출력해야함.
      // Key값들을 읽어와 자료를 출력하기
      // KeySet() => Map의 key 값들만 읽어와 Set형으로 반환
      Set<String> keySet = hotelMap.keySet();
      
      System.out.println("=====================================");
      System.out.println(" 번호\t객실번호\t\t이름 ");
      System.out.println("=====================================");

      if(keySet.size() == 0) {	// size() 메서드로 저장된 값이 0 이면 저장된 데이터가 없음
         System.out.println("등록된 룸이 없습니다");
      } else {
         
         // Set은 데이터의 순서가 없기 때문에 List처럼 인덱스로 데이터를 하나씩 불러올 수 없다.
         // 그래서 데이터를 하나씩 가져오기 위해서는 Iterator로 처리해야 한다.
         Iterator<String> it = keySet.iterator();
         
         int count = 0;   // 번호 카운트
         
         // 데이터 개수만큼 반복하기
         // hasNext() 메서드는 포인터 다음 위치에 데이터가 있다면 true, 없으면 false를 반환
         while(it.hasNext()) {
            count++;
            String rNum = it.next();	// next() 메서드 => 포인터를 다음 자료위치로 이동하고, 이동한 위치의 자료를 반환한다.
            Hotel h = hotelMap.get(rNum);	// 반환 받은 자료, 방번호(rNum)를 get()으로 받아와 Hotel 타입의 변수 h에 넣는다
            System.out.println(" " + count + "번"+ "\t" +"방번호 : "+ h.getrNum() +"\t" + "투숙객 : "+ h.getName());
         }
      }
      System.out.println("================================");
   }
   
   /**
    * 새로운 고객 정보를 등록하는 메서드
    */
   private void checkIn() {

      System.out.println();
      System.out.println("어느 방에 체크인 하시겠습니까?");
      System.out.print("방 번호 입력 => ");
      String rNum = sc.next();

      if (hotelMap.get(rNum) != null) {   // 입력된 방번호가 null이 아니라면
         System.out.println("죄송합니다. 다른 손님이 방을 사용중입니다.");
         return;
      }

      sc.nextLine();
      System.out.println("성함이 어떻게 되십니까?");
      System.out.print("이름 입력 => ");
      String name = sc.next();

      hotelMap.put(rNum, new Hotel(rNum, name));

      System.out.println(name + " 님 체크인 되었습니다.");
   }
   
   public static void main(String[] args) {
      HotelManager hm = new HotelManager();
      hm.hotelOpen();
   }


}

/**
 * 고객의 정보를 저장하기 위한 VO클래스
 */
class Hotel implements Serializable{   // 직렬화, 주로 객체들을 통째의 파일로 저장하거나 전송하고 싶을 때 사용
									   // 인터페이스를 구현한 클래스만 직렬화 할 수 있도록 되어 있다.
   
   // 직렬화가 되지 않을 멤버변수는 transient와 static으로 지정한다
   // 참조형 변수 : null, 숫자형 변수 : 0
   
   private String rNum;   // 방번호
   private String name;   // 이름
   
   public Hotel(String rNum, String name) {
      super();
      this.name = name;
      this.rNum = rNum;
   }
   
   public String getrNum() {
      return rNum;
   }


   public void setrNum(String rNum) {
      this.rNum = rNum;
   }


   public String getName() {
      return name;
   }


   public void setName(String name) {
      this.name = name;
   }


   @Override
   public String toString() {
      return "Hotel [rNum=" + rNum + ", name=" + name + "]";
   }
   
}