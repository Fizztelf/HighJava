package Practice;

import java.util.Scanner;

public class Employees {
	private Scanner sc;
	
	public Employees() {
	sc = new Scanner(System.in);
	}
	public void start() {
		while(true) {
			dispaly();
			String input = sc.next();
		}
	}
	
	
	private void dispaly() {
		System.out.println("대덕 회사에 오신 것을 환영합니다.");
		System.out.println();
	}
	public static void main(String[] args) {
		new Employees().start();
	}
}
