package kr.or.ddit.basic;

import java.util.ArrayList;
import java.util.List;

public class TestList {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("홍길동1");
		list.add("홍길동2");
		list.add("홍길동3");
		list.add("홍길동4");
		list.add("홍길동5");

		for(int i = 0; i<list.size(); i++) {
			System.out.println("삭제할 데이터 : " + i);
			list.remove(i);
		}
		System.out.println("size : " + list.size());
	}
	
}

//list는 순서가 있다. 중복을 허용한다.