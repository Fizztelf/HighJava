package kr.or.ddit.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.JDBCUtil;

public class BoardDaoImpl implements IBoardDao {

	private static IBoardDao bDao;

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private BoardDaoImpl() {
	}
	
	public static IBoardDao getInstance() {
		if(bDao == null) {
			bDao = new BoardDaoImpl();
		}
		return bDao;
	}
			
	@Override
	public int insertBoard(BoardVO bv) {
		int cnt = 0;

		try {

			conn = JDBCUtil.getConnection();
			String sql = "INSERT INTO JDBC_BOARD "
					+ " (BOARD_NO, BOARD_WRITER, BOARD_TITLE, BOARD_DATE, BOARD_CONTENT) "
					+ " VALUES (BOARD_SEQ.NEXTVAL,?,?,SYSDATE,?) ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoard_writer());
			pstmt.setString(2, bv.getBoard_title());
			pstmt.setString(3, bv.getBoard_content());

			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}
		return cnt;

	}

	@Override
	public List<BoardVO> DisplayBoardAll() {
		List<BoardVO> bList = new ArrayList<>();

		try {

			conn = JDBCUtil.getConnection();

			String sql = "SELECT * FROM JDBC_BOARD ";

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			while (rs.next()) {

				BoardVO bv = new BoardVO();

				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));

				bList.add(bv);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}
		return bList;
	}

	@Override
	public int updateBoard(BoardVO bv) {
		int cnt = 0;

		try {

			conn = JDBCUtil.getConnection();

			String sql = "UPDATE JDBC_BOARD " + "SET BOARD_TITLE = ? , " + " BOARD_CONTENT = ?, "
					+ " BOARD_DATE = SYSDATE " + " WHERE BOARD_NO = ? ";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bv.getBoard_title());
			pstmt.setString(2, bv.getBoard_content());
			pstmt.setString(3, bv.getBoard_no());
			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public boolean getBoard(String boardNo) {
		boolean chk = false;

		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT COUNT(*) CNT " + " FROM JDBC_BOARD " + " WHERE BOARD_NO = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);

			rs = pstmt.executeQuery();

			int count = 0;
			while (rs.next()) {
				count = rs.getInt("cnt");
			}

			if (count > 0) {
				chk = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			chk = false;
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}
		return chk;
	}

	@Override
	public int DeleteBoard(String boardNo) {
		int cnt = 0;

		try {

			conn = JDBCUtil.getConnection();

			String sql = "DELETE FROM JDBC_BOARD " + " WHERE BOARD_NO = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);

			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public List<BoardVO> SearchBoard(BoardVO bv) {
		List<BoardVO> bList = new ArrayList<>();

		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT * FROM JDBC_BOARD WHERE 1=1 ";

			if (bv.getBoard_title() != null && !bv.getBoard_title().equals("")) {
				sql += " AND BOARD_TITLE = ? ";
			}
			if (bv.getBoard_writer() != null && !bv.getBoard_writer().equals("")) {
				sql += " AND BOARD_WRITER = ? ";
			}
			if (bv.getBoard_content() != null && !bv.getBoard_content().equals("")) {
				sql += " AND BOARD_CONTENT LIKE '%' || ? || '%' ";
			}

			pstmt = conn.prepareStatement(sql);

			int index = 1;

			if (bv.getBoard_no() != null && !bv.getBoard_no().equals("")) {
				pstmt.setString(index++, bv.getBoard_no());
			}
			if (bv.getBoard_title() != null && !bv.getBoard_title().equals("")) {
				pstmt.setString(index++, bv.getBoard_title());
			}
			if (bv.getBoard_writer() != null && !bv.getBoard_writer().equals("")) {
				pstmt.setString(index++, bv.getBoard_writer());
			}
			if (bv.getBoard_date() != null && !bv.getBoard_date().equals("")) {
				pstmt.setString(index++, bv.getBoard_date());
			}
			if (bv.getBoard_content() != null && !bv.getBoard_content().equals("")) {
				pstmt.setString(index++, bv.getBoard_content());
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardVO bv2 = new BoardVO();
				bv2.setBoard_no(rs.getString("board_no"));
				bv2.setBoard_title(rs.getString("board_title"));
				bv2.setBoard_writer(rs.getString("board_writer"));
				bv2.setBoard_date(rs.getString("board_date"));
				bv2.setBoard_content(rs.getString("board_content"));

				bList.add(bv2);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.disConnect(conn, stmt, pstmt, rs);
		}

		return bList;
	}
}
