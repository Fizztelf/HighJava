package Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class Lotto {
	
	public void start() {
		Scanner sc = new Scanner(System.in);
		System.out.println("======================");
		System.out.println("Lotto 프로그램");

		System.out.println("1. Lotto 구입");
		System.out.println("2. 프로그램 종료");
		while (true) {
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 1. Lotto 구입
				LottoBuy();
				break;
			case 2:
				// 2.프로그램 종료
				System.exit(0);
			default:
				System.out.println("잘못입력하셨습니다.");
				break;
			}

		}
	}
	
	public void LottoBuy() {
		Set<Integer> s = new HashSet<Integer>();
		
//		System.out.println("로또 몇 장을 구입하시겠습니까?");
		System.out.println("로또 한 장의 금액은 1000원 입니다.");
		
		System.out.println("현재 소지한 금액을 입력하세요");
		Scanner sc = new Scanner(System.in);
		int user = sc.nextInt();

		if(user < 1000) {
			System.out.println("금액이 너무 작습니다. 다시 돈을 들고 오세요");
			return;
		} else if(user >= 51000) {
			System.out.println("금액이 너무 많아요. 50000원 밑으로만 입력하세요");
			return;
		}
		
//		int ticket = sc.nextInt();
//		int oneTicket = 1000;
		
		
		int num = user/1000;
		System.out.println("행운의 로또 번호는 아래와 같습니다.");
		
		for(int i =1; i <num; i++) {
			while(s.size()<6) {
				s.add((int)(Math.random()*45+1));
			}
		}
		
		List<Integer> list = new ArrayList<Integer>(s);
		
		Collections.sort(list);
		
		System.out.println(list);
		
		s.clear();
		
	}

	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.start();
	}

	

}

