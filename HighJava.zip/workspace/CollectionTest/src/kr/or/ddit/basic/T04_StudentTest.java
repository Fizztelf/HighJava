package kr.or.ddit.basic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 문제) 학번, 이름, 국어점수, 영어점수, 수학점수, 총점, 등수를 멤버로 갖는 
 *      Student 클래스를 만든다.
 *      생성자는 학번, 이름, 국어, 영어, 수학 점수만 매개변수를 받아서 처리한다.
 *      
 *      이 Student 객체들은 List에 저장하여 관리한다.
 *      List에 저장한 데이터들을 학번의 오름차순으로 정렬하여 출력하는
 *      부분과 총점이 역순으로 정렬하는 부분으로 프로그램 하시오
 *		(총점이 같으면 학번의 내림차순으로 정렬되도록 한다.)
 *		(학번 정렬 기준은 Student 클래스 자체에서 제공하도록 하고,
 *		총점 정렬기준은 외부클래스에서 제공하도록 한다.
 */
public class T04_StudentTest {
	public static void main(String[] args) {
		List<Student> stuList = new ArrayList<>();
		
		stuList.add(new Student("1560001", "김성준", 70, 60, 70));
		stuList.add(new Student("1560040", "김선준", 60, 90, 100));
		stuList.add(new Student("1560017", "박찬", 70, 60, 60));
		stuList.add(new Student("1560025", "전진원", 40, 60, 30));
		stuList.add(new Student("1560050", "박덕규", 90, 60, 50));
		stuList.add(new Student("1560039", "이상욱", 50, 70, 80));
		stuList.add(new Student("1560046", "오용선", 30, 50, 100));
		
		System.out.println("정렬 전 : " + stuList);
		for(Student stu : stuList) {
			System.out.println(stu);
		}
		System.out.println("=======================================================================================");
		
		Collections.sort(stuList);
		
		System.out.println("학번이 오름차순으로 정렬 후 : ");
		for(Student stu : stuList) {
			System.out.println(stu);
		}
		System.out.println("=======================================================================================");
		
		
		Collections.sort(stuList, new SortScoreDesc());
		
		System.out.println("총점 내림차순으로 정렬 후 : ");
		int a = 1;
		for(Student stu : stuList) {
			stu.setRank(a);
			a++;
//			
			System.out.println(stu);
		}
		System.out.println("=======================================================================================");
		
	}
}

class SortScoreDesc implements Comparator<Student> {

	//총점이 역순으로 정렬 (총점이 같으면 학번 내림차순으로 진행)
	@Override
	public int compare(Student stu1, Student stu2) {
		
		if(stu1.getSumScore() == stu2.getSumScore())  {
			//총점이 같으면 랭크도 같아야 함.
			return stu1.getId().compareTo(stu2.getId()) *-1;
		} else {
			return Integer.compare(stu1.getSumScore(), stu2.getSumScore()) *-1;
		}
		
	}
	
}




class Student implements Comparable<Student> {
	private String id;
	private String name;
	private int englishScore;
	private int mathScore;
	private int koreaScore;
	private int SumScore;
	private int rank;

	
	
	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	@Override
	public int compareTo(Student stu) {
		//학번 오름차순
		return id.compareTo(stu.getId());
	}
	
	public Student (String id, String name, int englishScore, int mathScore, int koreaScore) {
		super();
		this.id = id;
		this.name = name;
		this.englishScore = englishScore;
		this.mathScore = mathScore;
		this.koreaScore = koreaScore;
		this.SumScore = mathScore + koreaScore + englishScore;
	}
	

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", englishScore=" + englishScore + ", mathScore=" + mathScore
				+ ", koreaScore=" + koreaScore + ", SumScore=" + SumScore + ", rank = " + rank + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEnglishScore() {
		return englishScore;
	}

	public void setEnglishScore(int englishScore) {
		this.englishScore = englishScore;
	}

	public int getMathScore() {
		return mathScore;
	}

	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}

	public int getKoreaScore() {
		return koreaScore;
	}

	public void setKoreaScore(int koreaScore) {
		this.koreaScore = koreaScore;
	}

	public int getSumScore() {
	
		return SumScore;
	}

	public void setSumScore(int sumScore) {
		this.SumScore = sumScore;
	}
	
	
}