package Practice;

import java.util.ArrayList;
import java.util.List;

public class RaceHorse {

	public static void main(String[] args) {
		List<Horse2> list = new ArrayList<Horse2>();
		
		list.add(new Horse2("1번말"));		
		list.add(new Horse2("2번말"));		
		list.add(new Horse2("3번말"));		
		list.add(new Horse2("4번말"));		
		list.add(new Horse2("5번말"));		
		list.add(new Horse2("6번말"));		
		list.add(new Horse2("7번말"));		
		list.add(new Horse2("8번말"));		
		list.add(new Horse2("9번말"));		
		list.add(new Horse2("0번말"));		
	}
}


class Horse extends Thread {


}

class Horse2 extends Thread implements Comparable<Horse2> {
	
		private String name;
	    private int rank = 0;
	    private int location = 0;
	    public volatile boolean goal = false; // 결승지점 통과 여부
	    
	    @Override
	    public void run() {
	    	int cnt = 0;
	    	while (true) {
	    		location += cnt;
	    		try {
	    			Thread.sleep(1000 * (int) (Math.random() * 4));
	    		} catch (InterruptedException e) {
	    			e.printStackTrace();
	    		}
	    		
	    		if (location == 50) {
	    			break;
	    		}
	    		cnt++;
	    	}
	    }
	    
	    
	    public Horse2(String name) {
	    	this.name = name;
	    }

		public String getHName() {
			return name;
		}

		public int getRank() {
			return rank;
		}

		public int getLocation() {
			return location;
		}

		public boolean isGoal() {
			return goal;
		}




	@Override
	public int compareTo(Horse2 h) {
		return getHName().compareTo(h.getHName());
	}
	
}