package kr.or.ddit.member.handler;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.common.handler.CommandHandler;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.member.vo.PagingVO;

public class ListMemberHandler implements CommandHandler{

	private static final String VIEW_PAGE = "/WEB-INF/views/member/list.jsp";
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws Exception {


		if(req.getMethod().equals("GET")) {
			int pageNo = req.getParameter("pageNo") == null ? 1 : Integer.parseInt(req.getParameter("pageNo"));
			
			String msg = req.getParameter("msg") == null ? "" : req.getParameter("msg");
			
			System.out.println("msg : " + msg);
			
			// 1. 서비스 객체 생성하기 
			IMemberService memberService = MemberServiceImpl.getInstance();
			
			// 2. 페이징 객체 생성
			PagingVO pagingVO = new PagingVO();
			int totalCount = memberService.SelectTotalCount();
			pagingVO.setTotalCount(totalCount);
			pagingVO.setCurrentPageNo(pageNo);
			pagingVO.setCountPerPage(5);
			pagingVO.setPageCount(5);
			
			// 3. 회원정보 조회
			List<MemberVO> memList = memberService.displayMemberByPaing(pagingVO);
			req.setAttribute("msg", msg);
			req.setAttribute("memList", memList);
			req.setAttribute("pagingVO", pagingVO);
			return VIEW_PAGE;
			
		} else /*if(req.getMethod().equals("POST"))*/ {	 // POST
			
		}
		return null;
			
		
	}

	@Override
	public boolean isRedirect() {
		// TODO Auto-generated method stub
		return false;
	}

}
