package kr.or.ddit.common;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.log4j.Logger;

import kr.or.ddit.common.handler.CommandHandler;
import kr.or.ddit.member.handler.NullHandler;
import kr.or.ddit.util.FileUploadRequestWrapper;

public class WebController extends HttpServlet{
	
	private static Logger logger = Logger.getLogger(WebController.class);
	
	
	// 매핑정보를 저장(핸들러 객체 저장용 맵)
	private Map<String, CommandHandler> commandHandlerMap = new HashMap<String, CommandHandler>();
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		String configFilePath = config.getInitParameter("handler-config");
		
		Properties handlerProp = new Properties();
		
		// 설정파일을 읽어서 대응되는 핸들러 객체를 생성하여 맵에 등록하기
		
		//String configFileRealPath = getServletConfig();
		String configFileRealPath = config.getServletContext().getRealPath(configFilePath); // getRealPath 메서드가 있기 때문에 ServletContext() 메서드를 씀
	
		FileReader fr;
		try {
			fr = new FileReader(configFileRealPath);
			handlerProp.load(fr);
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		for(Object key : handlerProp.keySet()) {
			String command = (String) key;
			
			try {
				Class<?> klass = Class.forName(handlerProp.getProperty(command));	// 클래스이름을 가지고 클래스 객체 정보를 만든다.
//				Class<?> klass = WebController.class; // WebController 클래스 정보를 변수 klass에 담는다.
				CommandHandler handlerInstance = (CommandHandler) klass.newInstance();
				// 핸들러 객체 등록
				commandHandlerMap.put(command, handlerInstance);
			} catch(Exception e) {
				e.printStackTrace();
				throw new ServletException();
			}
		}
		
		logger.info("CommandHandler 매핑 정보\n => " + commandHandlerMap);
	}
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// 파일 업로드 처리를 위한 래퍼클래스 사용하기
		try {
			FileUploadRequestWrapper requestWrapper = new FileUploadRequestWrapper(req);
			process(requestWrapper, resp);
			
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String command = req.getRequestURI();
		System.out.println("전 command =>" + command);
		
		if(command.indexOf(req.getContextPath()) == 0) {
			command = command.substring(req.getContextPath().length());
		}
		
		System.out.println("후 command =>" + command);
		
		CommandHandler handler = commandHandlerMap.get(command);
		
		if(handler == null) {
			handler = new NullHandler();
		}
		
		String viewPage = "";	// 뷰 화면 정보
		try {
			viewPage = handler.process(req, resp);
		} catch(Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
		
		logger.info(viewPage);
		
		// VIEW 화면 처리
		if(viewPage != null) { // view 정보가 존재하면...
			if(handler.isRedirect(req)) { // redirect 처리가 필요하면...
				resp.sendRedirect(viewPage);
			} else {
				RequestDispatcher disp = req.getRequestDispatcher(viewPage);
				disp.forward(req, resp);
			}
		}
		
	}

}
