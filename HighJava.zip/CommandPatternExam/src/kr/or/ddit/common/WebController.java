package kr.or.ddit.common;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WebController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// 작업 처리...
		String command = req.getRequestURI();
		System.out.println("command => " + command);
//		if(command.equals("/upload.do")) {
//			new 파일업로드클래스().파일업로드();
//		} else if(command.equals("/download.do")) {
//			new 파일다운로드클래스().다운로드();
//		} else if(command.equals("/sendmail.do")) {
//			new 메일발송로드클래스().메일발송();
//		}
		
		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
