package Practice;

/**
 * 문제) 태양계 행성을 나타내는 enum Planet을 이용하여 구하시오. (단, enum 객체 생성시 반지름을 이용하도록 정의하시오.)
 * 
 * 예) 행성의 반지름(KM):
 *  수성(2439),
 *  금성(6052),
 *  지구(6371),
 *  성(3390),
 *  목성(69911),
 *  토성(58232),
 *  천왕성(25362),
 *  해왕성(24622)
 */
public class PlanetTest {

	public enum Planet {
		수성(2439), 
		금성(6052), 
		지구(6371), 
		성(3390), 
		목성(69911), 
		토성(58232), 
		천왕성(25362), 
		해왕성(24622);
	
	private int l;
	

	Planet(int data) {
		l = data;
	}
	
	public int getL() {
		return l;
	}
	
}
	public static void main(String[] args) {
		
		Planet[] enumArr = Planet.values();
		// 면적을 구하는 방식은 : 4πr^2
		// π = 3.141592...
		float pi = 3.141592f;
		for(int i = 0; i < enumArr.length; i++) {
			System.out.println("-----------------------------------------------------------");
			System.out.println(enumArr[i].name() + " : " + enumArr[i].getL() + "\t=>\t" + "면적 : "+ enumArr[i].getL()*enumArr[i].getL()*pi*4 +" Km²");
			System.out.println("-----------------------------------------------------------");
		}
	}	
}