package kr.or.ddit.member.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVO;
import sun.security.jca.GetInstance;

public class MemberServiceImpl implements IMemberService{
	
	private IMemberDao memDao;
	private static IMemberService service;
	
	public MemberServiceImpl() {
		try {
			memDao = MemberDaoImpl.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static IMemberService getInstance() {
		if(service == null) {
			service = new MemberServiceImpl();
		}
		return service;
	}
	
	@Override
	public int insertMember(MemberVO mv)  {
		
		int cnt = 0;
		
		try {
			cnt = memDao.insertMember(mv);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	@Override
	public int deleteMember(String memId) {
		
		int cnt = 0;
		
		try {
			cnt =  memDao.deleteMember(memId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public int updateMember(MemberVO mv) {
		
		int cnt= 0;
		
		try {
			cnt =  memDao.updateMember(mv);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public List<MemberVO> displayMemberAll() {
		
		List<MemberVO> memList = new ArrayList<>();
		
		try {
			memList = memDao.displayMemberAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return memList;
	}

	@Override
	public MemberVO getMember(String memId) {
		
		MemberVO mv = null;
		
		try {
			mv = memDao.getMember(memId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {
		
		List<MemberVO> memList = new ArrayList<>();
		
		try {
			memList = memDao.getSearchMember(mv);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return memList;
	}
}
