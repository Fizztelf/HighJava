package Practice;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * 'd:/D_Other/'에 있는 'Tulips.jpg'파일을

'복사본_Tulips.jpg'로 복사하는 프로그램을

작성하시오.

1.버퍼 이용
2.버퍼 비이용
 */
public class FileCopy {
public static void main(String[] args) {
		
		File src = new File("d:/D_Other/Tulips.jpg");	// 절대경로
		File dist = new File("d:/D_Other/복사본_Tulips.jpg");
		
		
		//FileInputStream 객체를 이용한 파일 읽기 
		FileInputStream fis = null;
		//FileOutputStream 객체를 이용한 파일 출력하기
		FileOutputStream fos = null;
		
		// 기본 스트림을 보조하는 버퍼 스트림
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		
		try {
			// 입출력 바이트 스트림 연결
			fis = new FileInputStream(src);
			fos = new FileOutputStream(dist);
			
			// 원본 파일 읽기 
			bis = new BufferedInputStream(fis);
			// 원본 파일 복사
			bos = new BufferedOutputStream(fos);
			
			int c;	// 읽어올 데이터를 저장하는 변수
			
			// read() => byte 단위로 자료를 읽어와 int형으로 반환
			// 		  => 더 이상 읽어올 자료가 없으면 -1을 반환
			while((c=bis.read()) != -1) {
				bos.write(c);
			}
			
			System.out.println("복사 완료...");
			
			// 스트림 객체 닫기
			bis.close();
			bos.close();
			fos.close();
			fis.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
