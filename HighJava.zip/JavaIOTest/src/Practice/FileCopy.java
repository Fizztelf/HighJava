package Practice;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * 'd:/D_Other/'에 있는 'Tulips.jpg'파일을

'복사본_Tulips.jpg'로 복사하는 프로그램을

작성하시오.

1.버퍼 이용
2.버퍼 비이용
 */
public class FileCopy {
	public static void main(String[] args) {
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream("d:/D_Other/Tulips.jpg");
			fos = new FileOutputStream("d:/D_Other/복사본_Tulips.jpg");
		
			byte[] buffer = new byte[1024];
			int c = 0;
			
			while((c=fis.read(buffer))!=-1) {
				fos.write(buffer, 0, c);
			}
		
		
			fis.close();
			fos.close();
		
		} catch(Exception e) {
			e.printStackTrace();
		} 	
	}
}
