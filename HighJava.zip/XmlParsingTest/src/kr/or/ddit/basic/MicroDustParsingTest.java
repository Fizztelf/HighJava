package kr.or.ddit.basic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * 공공 Api를 사용해 xml 파싱하기
 */
public class MicroDustParsingTest {

	public void parsing() {
		try {
			// 파일을 따로 생성치 않고 즉시 xml의 문자열을 받아옴
			StringBuilder xml = ApiExplorer();
			InputSource is = new InputSource(new StringReader(xml.toString()));
			
			// DOM Document 객체 생성
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = dbf.newDocumentBuilder();
			Document xmlDoc = builder.parse(is);
//			 오늘 날짜
			SimpleDateFormat format = new SimpleDateFormat("yyyy년 MM월 dd일");
			Calendar time = Calendar.getInstance();
			String todayDate = format.format(time.getTime());
			
			Element root = xmlDoc.getDocumentElement();
			NodeList itemNodeList =  root.getElementsByTagName("item");
			
			System.out.println("-----------------------------------------------------");
			
			for(int i=0; i<itemNodeList.getLength(); i++) {
				Node node = itemNodeList.item(i);
				Element element = (Element) node;
				
				String daseData = element.getElementsByTagName("baseData").item(0).getTextContent();
				String issueData = element.getElementsByTagName("issueData").item(0).getTextContent();
				String issueTime = element.getElementsByTagName("issueTime").item(0).getTextContent();
				String clearTime = element.getElementsByTagName("clearTime").item(0).getTextContent();
				
				issueData = issueData.substring(0, 2).concat("시");
				clearTime = clearTime.substring(0, 2).concat("시");
				
				String[] originalCategory = {"districName","moveName","issueVal","alarmStep","clearVal","maxVal"};
				String[] replaceCategory = {"지역명","권역명","발령농도","경보단계","해제농도","최고농도"};
				
				for(int j=0; i <originalCategory.length; j++) {

				}
			
			}
			
			
			
			
			
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private StringBuilder ApiExplorer() throws IOException {

		
		StringBuilder urlBuilder = new StringBuilder(
				"http://openapi.airkorea.or.kr/openapi/services/rest/UlfptcaAlarmInqireSvc/getUlfptcaAlarmInfo"); 
		urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8") + "=4Ky1yhWgoS3nm2gmnXXgR7QyjFPa7rZxwqMeE2O53BySkQYiGuvv0i%2BsHsd0om225bnFzRsK8veaJgiII4QCvg%3D%3D"); /* Service Key */
		urlBuilder.append("&" + URLEncoder.encode("ServiceKey", "UTF-8") + "="
				+ URLEncoder.encode("-", "UTF-8")); /* 공공데이터포털에서 받은 인증키 */
		urlBuilder
				.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /* 페이지번호 */
		urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "="
				+ URLEncoder.encode("10", "UTF-8")); /* 한 페이지 결과 수 */
		urlBuilder.append(
				"&" + URLEncoder.encode("year", "UTF-8") + "=" + URLEncoder.encode("2013", "UTF-8")); /* 측정 연도 */
		urlBuilder.append("&" + URLEncoder.encode("itemCode", "UTF-8") + "="
				+ URLEncoder.encode("PM10", "UTF-8")); /* 미세먼지 항목 구분(PM10, PM25) PM10, PM25 모두 조회할 경우 파라미터 생략 */
		
		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("Response code: " + conn.getResponseCode());
		
		BufferedReader rd;
		
		if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		
		StringBuilder sb = new StringBuilder();
		String line;
		
		while ((line = rd.readLine()) != null) {
			sb.append(line);
		}
		
		rd.close();
		conn.disconnect();
		System.out.println(sb.toString());
		
		return sb;
	}

	public static void main(String[] args) {
		new MicroDustParsingTest().parsing();
	}
}
