package kr.or.ddit.reflection;

/**
 * 1. 리플렉션은 클래스, 또는 멤버변수, 메서드,  생성자에 대한 정보를 가져오거나 수정할 수 있다.
 * 2. Reflection API는 java.lang.reflection 패키지와 java.lang.Class를 통해서 제공된다.
 * 3. java.lang.Class의 주요 메서드
 *    - getName(), getSuperClass(), getInterface(), getModifiers()
 * 4. java.lang.reflect 패키지의 주요 클래스
 *    - Field, Method, Constructor, Modifier 등. 
 */

// Class 오브젝트(클래스의 정보를 담고있는)를 발생하기
public class T01_CalssObjectCreationTest {
	public static void main(String[] args) throws ClassNotFoundException {
		
		// 첫 번째 방법 : Class.forName() 메서드 이용
		Class<?> klass = Class.forName("kr.or.ddit.reflection.T01_CalssObjectCreationTest");
	
		// 두 번째 방법 : getClass() 메서드 이용
		T01_CalssObjectCreationTest obj = new T01_CalssObjectCreationTest();
		klass = obj.getClass();
		
		// 세 번째 방법 : .class이용
		klass = T01_CalssObjectCreationTest.class;
	}
}
