package kr.or.ddit.behavioral.strategy;

public class OperationCustom implements Strategy{

	@Override
	public int doOperation(int num1, int num2) {
		// 내 마음대로 전략...
		return num1+num2*num1*num2-num2-num1;
	}

}
