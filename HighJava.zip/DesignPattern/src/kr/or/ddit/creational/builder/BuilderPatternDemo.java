package kr.or.ddit.creational.builder;

public class BuilderPatternDemo {
	public static void main(String[] args) {
		
		Member member = new Member.Builder("홍길동", 18).birthData("2000-03-22").hobby("독서").build();
		
		System.out.println(member);
	}
}
