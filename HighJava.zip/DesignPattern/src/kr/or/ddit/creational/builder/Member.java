package kr.or.ddit.creational.builder;

/**
 * 빌더 패턴 : 인자가 많은 생성자나 정적 팩토리가 필요한 클래스를 설계할 때 사용
 *          특히, 대부분의 인자값이 선택적인 상황에 유용함.
 *          
 * - 점층적 생성자 패턴보다 가독성이 좋아진다
 * - 생성된 객체는 자바빈을 사용할 때보다 안전해진다 (Immutable 객체)
 */
public class Member {
	// 필수 값
	private String name;
	private int age;
	
	// 선택 값 (넣어도 되고 안 넣어도 됨)
	private String tel;
	private String address;
	private String hobby;
	private String birthData;

	public static class Builder{
		// 필수 값
		private String name;
		private int age;
		
		// 선택 값 (넣어도 되고 안 넣어도 됨)
		private String tel;
		private String address;
		private String hobby;
		private String birthData;
		
		public Builder(String name, int age) {
			this.name = name;
			this.age = age;
		}
		
		public Builder tel(String tel) {
			this.tel = tel;
			return this;
		}
		
		public Builder address(String address) {
			this.address = address;
			return this;
		}
		public Builder hobby(String hubby) {
			this.hobby = hubby;
			return this;
		}
		public Builder birthData(String birthData) {
			this.birthData = birthData;
			return this;
		}
		
		// Builder 객체를 이용하여 Member 객체 생성하기
		public Member build() {
			return new Member(this);
		}
	}
	
	// 생성자를 private 설정함(Builder 객체에서는 호출 가능)
	private Member(Builder builder) {
 		this.name = builder.name;
		this.tel = builder.tel;
		this.age = builder.age;
		this.address = builder.address;
		this.hobby = builder.hobby;
		this.birthData = builder.birthData;
	}


	@Override
	public String toString() {
		return "Member [name=" + name + ", age=" + age + ", tel=" + tel + ", address=" + address + ", hobby=" + hobby
				+ ", birthData=" + birthData + "]";
	}
	
	

}
