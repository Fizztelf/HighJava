package kr.or.ddit.creational.factory;

public interface Shape {
	void draw();
}
