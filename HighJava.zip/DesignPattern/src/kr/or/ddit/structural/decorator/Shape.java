package kr.or.ddit.structural.decorator;

public interface Shape  {
	void draw();
}
