package kr.or.ddit.board.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;

@WebServlet("/viewBoard")
public class ViewBoardServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String boardNo = req.getParameter("boardNo");
		
		// 1. 서비스 객체 생성
		IBoardService boardService = BoardServiceImpl.getInstance();
		
		// 2. 게시판 정보 조회
		BoardVO bv = new BoardVO();
		bv.setBoardNo(boardNo);
		
		BoardVO boardVO = boardService.getBoard(boardNo);
		
		req.setAttribute("boardVO", boardVO);
		
		// 3. 결과를 VIEW 화면에 출력하기
		RequestDispatcher disp = req.getRequestDispatcher("/WEB-INF/views/board/view.jsp");
		disp.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
