package kr.or.ddit.board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;

@WebServlet("/SelectAllBoard")
public class SelectAllBoardServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int pageNo = req.getParameter("pageNo") == null ? 1 : Integer.parseInt(req.getParameter("pageNo"));
	
		String msg = req.getParameter("msg") == null ? "" : req.getParameter("msg");
		
		System.out.println("msg : " + msg);
		
		// 1. 서비스 객체 생성하기
		IBoardService boardService = BoardServiceImpl.getInstance();
		
		// 2. 페이징 객체 생성
		
		// 3. 게시판 정보 조회
//		List<BoardVO> boardList = (List<BoardVO>) req.getRequestDispatcher("WEB-INF/views/board/list.jsp");
		List<BoardVO> boardList = boardService.DisplayBoardAll();
		req.setAttribute("msg", msg);
		req.setAttribute("boardList", boardList);
		
		RequestDispatcher disp = req.getRequestDispatcher("WEB-INF/views/board/list.jsp");
		disp.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
