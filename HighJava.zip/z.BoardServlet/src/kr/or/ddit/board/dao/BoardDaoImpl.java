package kr.or.ddit.board.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.board.vo.PagingVO;
import kr.or.ddit.util.JDBCUtil;
import kr.or.ddit.util.SqlMapClientFactory;

public class BoardDaoImpl implements IBoardDao {

	private static IBoardDao bDao;

	private SqlMapClient smc;
	
	private BoardDaoImpl() throws Exception {
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static IBoardDao getInstance() throws Exception{
		if(bDao == null) {
				bDao = new BoardDaoImpl();
		}
		return bDao;
	}
	
	@Override
	public int insertBoard(BoardVO bv) throws Exception{
		
		int cnt = 0;
		
			Object obj = smc.insert("boardTest.insertBoard", bv);
			
			if(obj == null) {
				cnt = 1;
			}
		return cnt;
	}
	
	@Override
	public int DeleteBoard(String boardNo) throws Exception {
		int cnt = 0;
		
			cnt = smc.delete("boardTest.deleteBoard", boardNo);
		
		return cnt;
	}

	@Override
	public int updateBoard(BoardVO bv) throws Exception{
		int cnt = 0;
		
			cnt = smc.update("boardTest.updateBoard", bv);
		
		return cnt;
	}
	
	@Override
	public List<BoardVO> DisplayBoardAll() throws Exception{
		List<BoardVO> bList = new ArrayList<>();

			bList = smc.queryForList("boardTest.getBoardAll");
		
		return bList;
	}


	@Override
	public BoardVO getBoard(String boardNo) throws Exception{

		BoardVO bv = (BoardVO) smc.queryForObject("boardTest.getBoard", boardNo);
			
			
		return bv;
	}


	@Override
	public List<BoardVO> SearchBoard(BoardVO bv) throws Exception{
		List<BoardVO> bList = new ArrayList<>();

			bList = smc.queryForList("boardTest.SearchBoard", bv);
		
		return bList;
	}

	@Override
	public List<BoardVO> displayBoardByPaging(PagingVO pagingVO) throws Exception {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		boardList = smc.queryForList("boardTest.getBoardByPaging", pagingVO);
		
		return boardList;
	}

	@Override
	public int SelectTotalCount() throws Exception {
		int totalCnt = (int) smc.queryForObject("boardTest.SelectTotalCount");
		
		return totalCnt;
	}
}
