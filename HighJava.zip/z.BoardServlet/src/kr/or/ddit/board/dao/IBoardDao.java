package kr.or.ddit.board.dao;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.board.vo.PagingVO;

public interface IBoardDao {

	public int insertBoard(BoardVO bv) throws Exception;

	public List<BoardVO> DisplayBoardAll() throws Exception;

	public int updateBoard(BoardVO bv) throws Exception;

	public BoardVO getBoard(String boardNo) throws Exception;

	public int DeleteBoard(String boardNo) throws Exception;

	public List<BoardVO> SearchBoard(BoardVO bv) throws Exception;
	
	public List<BoardVO> displayBoardByPaging(PagingVO pagingVO) throws Exception;

	public int SelectTotalCount() throws Exception;
}
