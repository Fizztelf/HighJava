package kr.or.ddit.board.dao;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardDao {

	public int insertBoard(BoardVO bv) throws Exception;

	public List<BoardVO> DisplayBoardAll() throws Exception;

	public int updateBoard(BoardVO bv) throws Exception;

	public BoardVO getBoard(String boardNo) throws Exception;

	public int DeleteBoard(String boardNo) throws Exception;

	public List<BoardVO> SearchBoard(BoardVO bv) throws Exception;
	
}
