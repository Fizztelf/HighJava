package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.board.vo.PagingVO;

public interface IBoardService {

	public int insertBoard(BoardVO bv);

	public List<BoardVO> DisplayBoardAll();

	public int updateBoard(BoardVO bv);

	public BoardVO getBoard(String boardNo);

	public int DeleteBoard(String boardNo);

	public List<BoardVO> SearchBoard(BoardVO bv);

	public List<BoardVO> displayBoardByPaging(PagingVO pagingVO);

	public int SelectTotalCount();
}
