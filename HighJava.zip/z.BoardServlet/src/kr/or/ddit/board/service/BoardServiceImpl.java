package kr.or.ddit.board.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.board.vo.PagingVO;

public class BoardServiceImpl implements IBoardService{

	private IBoardDao bDao;
	private static IBoardService service;
	
	public BoardServiceImpl() {
		try {
			bDao = BoardDaoImpl.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static IBoardService getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}
	
	@Override
	public int insertBoard(BoardVO bv) {
		int cnt = 0;
		try {
			cnt = bDao.insertBoard(bv);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	@Override
	public List<BoardVO> DisplayBoardAll() {
		
		List<BoardVO> boardList= new ArrayList<>();
		try {
			boardList = bDao.DisplayBoardAll();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return boardList;
	}
	@Override
	public int updateBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			cnt =  bDao.updateBoard(bv); 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	@Override
	public BoardVO getBoard(String boardNo) {
		BoardVO bv = new BoardVO();
		
		try {
			bv = bDao.getBoard(boardNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bv;
	}
	@Override
	public int DeleteBoard(String boardNo) {
		int cnt = 0;
		try {
			cnt = bDao.DeleteBoard(boardNo);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	@Override
	public List<BoardVO> SearchBoard(BoardVO bv) {
		List<BoardVO> boardList = new ArrayList<>();
		
		try {
			boardList = bDao.SearchBoard(bv);
		} catch(Exception e) {
			e.printStackTrace();
		}
		 return boardList;
	}

	@Override
	public List<BoardVO> displayBoardByPaging(PagingVO pagingVO) {
		List<BoardVO> boardList = new ArrayList<>();
		
		try {
			boardList = bDao.displayBoardByPaging(pagingVO);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return boardList;
	}

	@Override
	public int SelectTotalCount() {
		int totalCnt = 0;
		
		try {
			 totalCnt = bDao.SelectTotalCount();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return totalCnt;
	}
}
